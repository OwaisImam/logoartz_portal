Hey {{$user}},
This is to inform You That Your {{$type}} For {{$design}} is Approved By Admin in ${{$amount}} Please Confirm Your {{$type}}.
<br><a href="somelink.html">Confirm Your {{$type}} Now</a>