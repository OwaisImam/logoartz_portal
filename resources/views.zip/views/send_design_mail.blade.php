Hey {{$user}},
Your Order For Vector Design is Completed Please Click the link below to Confirm your Order.
<br><a href="{{url('CustomerDash')}}">Confirm Your Order Now</a>
<br><h4>Regards,</h4>
<h3>Team LogoArtz</h3>