<div class="modal fade" id="MessageModal" tabindex="-1" role="dialog" aria-labelledby="MessageModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="MessageModalLabel"></h4>
            </div>
            <div class="modal-body">
                <h5></h5>
            </div>
            <div class="modal-footer"> </div>
        </div>
    </div>
</div>
<footer class="main-footer">
    <div class="container">
        <div class="pull-right hidden-xs"> </div>
        <strong>Copyright &copy; 2021</strong>
    </div>
</footer>
