<style type="text/css">
    table td, table th{
        border:1px solid black;
    }
</style>
<div class="container">


    <br/>
    <a href="{{ url('/dpdf') }}">Download PDF</a> 


    <table>
        <tr>
            <th>Order Num</th>
            <th>Title</th>
            <th>Description</th>
        </tr>
      
        <tr>
            <td> 1222</td>
            <td>digitizing</td>
            <td>ABBBBBBBBBCCCC</td>
        </tr>
    </table>
</div>